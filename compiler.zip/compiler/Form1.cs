﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


 public struct T_Lines
{
   public string[] token;
};

namespace compiler

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void compileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string code;
            string[] Lines;
            code =textBox1.Text;
            T_Lines[] L = new T_Lines[1];
            Lines = code.Split('\n');

         

            for (int i = 0; i < Lines.Length; i++)
              Lines[i] = string.Join(" ", Lines[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));

            for (int i = 0; i < Lines.Length; i++)
            {
                if (i == L.Length - 1)
                   L= increaseSize(L);
                
               L[i].token = Lines[i].Split();
            }   
            
           Form2 f2 = new Form2((string)L[2].token[0]);
            f2.Show();
        }

        public T_Lines[] increaseSize(T_Lines[] L)
        {
            T_Lines[] L1 = new T_Lines[L.Length + 1];
            for (int i = 0; i < L.Length; i++)
                L1[i] = L[i];

            return L1;
        }
       

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "txt";
            sfd.FileName = "*.txt";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                Stream fs = sfd.OpenFile();
                StreamWriter sw = new StreamWriter(fs);
                sw.Write(textBox1.Text);
                sw.Close();
                fs.Close();
                textBox1.Text = "";
                MessageBox.Show("File has been saved", "Message", MessageBoxButtons.OK);
                
            
            }

        }

       

        }
    }

